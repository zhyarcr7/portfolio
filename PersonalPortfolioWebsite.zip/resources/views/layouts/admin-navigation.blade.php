                        <x-dropdown-link :href="route('admin.testimonials.index')">
                            {{ __('Testimonials') }}
                        </x-dropdown-link>
                        
                        <x-dropdown-link :href="'/zhyar-cv-direct'">
                            {{ __('Zhyar CV') }}
                        </x-dropdown-link>
                    </x-slot>
                </x-dropdown> 