<?php

// Fix SSL certificate issues early in the application boot process
require_once __DIR__ . '/../config/ssl-fix.php'; 